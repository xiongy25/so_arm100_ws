# SO-ARM100 机械臂写字功能

本功能包实现了使用SO-ARM100机械臂写汉字的功能。目前支持写出"二四再见"四个汉字。

## 功能特点

- 基于ROS2和MoveIt实现机械臂轨迹规划和控制
- 结合使用MoveIt规划和笛卡尔路径规划，实现更流畅的写字效果
- 支持笔画分解和轨迹生成
- 动态速度控制，模拟人类写字习惯
- 可调节写字大小、位置和速度
- 实现抬笔和落笔动作
- 支持连续书写多个汉字

## 路径规划策略

本系统采用混合路径规划策略，结合了MoveIt规划和笛卡尔路径规划的优点：

1. MoveIt规划（用于大范围运动）：
   - 抬笔和落笔动作
   - 字与字之间的移动
   - 回到安全位置
   - 使用较高速度（30%）提高效率

2. 笛卡尔路径规划（用于写字笔画）：
   - 确保笔画轨迹的连续性和平滑性
   - 使用较小步长（0.001米）实现精确控制
   - 使用较低速度（10%）保证写字质量
   - 自动检查路径完整性

## 依赖项

- ROS2
- MoveIt
- Python 3
- geometry_msgs
- tf2_ros
- tf2_geometry_msgs

## 安装

1. 确保已安装ROS2和MoveIt

2. 克隆代码到工作空间：
```bash
cd ~/ros2_ws/src
git clone <repository_url>
```

3. 编译功能包：
```bash
cd ~/ros2_ws
colcon build --packages-select so_arm100_writing
```

4. 刷新环境：
```bash
source ~/ros2_ws/install/setup.bash
```

## 使用方法

1. 启动机械臂和MoveIt：
```bash
ros2 launch so_arm100_moveit_config move_group.launch.py
```

2. 运行写字程序：
```bash
ros2 run so_arm100_writing write_characters.py
```

## 参数配置

在`write_characters.py`中可以调整以下参数：

```python
# 写字区域的参数
self.writing_surface_height = 0.1  # 写字平面的高度（米）
self.char_size = 0.05             # 每个字的大小（米）
self.start_x = 0.2               # 起始位置X坐标
self.start_y = 0.0               # 起始位置Y坐标
self.writing_speed = 0.05        # 写字速度（米/秒）

# 速度控制参数
self.arm_group.set_max_velocity_scaling_factor(0.3)      # 一般移动速度
self.arm_group.set_max_acceleration_scaling_factor(0.3)  # 加速度缩放因子

# 笛卡尔路径规划参数
eef_step = 0.001  # 笛卡尔路径步长（米）
jump_threshold = 0.0  # 跳跃阈值
```

## 路径规划过程

1. 写字准备：
   - 机械臂移动到初始位置（MoveIt规划）
   - 调整末端执行器姿态，使笔尖垂直于写字平面

2. 单个字的写字过程：
   - 使用MoveIt规划移动到笔画起点上方
   - 使用MoveIt规划执行落笔动作
   - 使用笛卡尔路径规划执行笔画
   - 使用MoveIt规划执行抬笔动作
   - 重复以上步骤直到完成所有笔画

3. 速度控制：
   - 大范围移动：使用30%的最大速度
   - 写字笔画：使用10%的最大速度
   - 动态调整速度以模拟人类写字习惯

## 注意事项

1. 使用前请确保：
   - 机械臂已正确安装并校准
   - 末端执行器已安装合适的写字工具
   - 写字平面已正确放置

2. 路径规划相关：
   - 确保写字区域在机械臂的工作空间内
   - 检查笛卡尔路径规划的完整性（默认要求90%以上）
   - 观察轨迹是否平滑，必要时调整步长参数

3. 参数调整：
   - 根据实际工作空间调整坐标参数
   - 可以通过修改速度参数调整写字效果
   - 字的大小和间距可以根据需要调整

## 代码结构

主要实现文件：
- `scripts/write_characters.py`: 主程序文件
  - `CharacterWriter`类：实现写字功能
  - `move_to_point`：MoveIt规划方法
  - `move_cartesian_path`：笛卡尔路径规划方法
  - `write_stroke`：笔画执行方法
  - 各个汉字的笔画定义

## 故障排除

1. 如果笔画不够流畅：
   - 减小笛卡尔路径规划的步长
   - 降低写字速度
   - 检查速度和加速度缩放因子

2. 如果路径规划失败：
   - 检查点位是否在工作空间内
   - 查看警告日志中的路径完整性百分比
   - 调整写字区域的位置和大小

3. 如果抬笔落笔不准确：
   - 调整抬笔高度参数
   - 检查末端执行器姿态
   - 确保写字平面水平

## 维护与支持

如有问题或建议，请提交Issue或Pull Request。

## 许可证

[许可证名称] - 查看LICENSE文件了解更多信息。
