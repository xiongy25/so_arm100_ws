#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from moveit_commander import MoveGroupCommander, RobotCommander
from geometry_msgs.msg import Pose, Point, TwistStamped
from std_msgs.msg import Header
from copy import deepcopy
import sys
import numpy as np
from tf2_ros import TransformListener, Buffer
from rclpy.duration import Duration

class CharacterWriter(Node):
    def __init__(self):
        super().__init__('character_writer')
        
        # 初始化MoveIt相关对象
        self.robot = RobotCommander()
        self.arm_group = MoveGroupCommander("arm")
        self.gripper_group = MoveGroupCommander("gripper")
        
        # 设置运动参数
        self.arm_group.set_max_velocity_scaling_factor(0.3)
        self.arm_group.set_max_acceleration_scaling_factor(0.3)
        
        # 定义写字区域的参数（需要根据实际情况调整）
        self.writing_surface_height = 0.1  # 写字平面的高度（米）
        self.char_size = 0.05  # 每个字的大小（米）
        self.start_x = 0.2  # 起始位置X坐标
        self.start_y = 0.0  # 起始位置Y坐标
        self.writing_speed = 0.05  # 写字速度（米/秒）
        
        # 初始化TF监听器
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
    def move_to_point(self, x, y, z, pen_down=True):
        """使用MoveIt规划移动到指定点位（用于大范围移动）"""
        pose = self.arm_group.get_current_pose().pose
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z
        
        # 保持末端执行器朝下
        pose.orientation.x = 0.0
        pose.orientation.y = 1.0
        pose.orientation.z = 0.0
        pose.orientation.w = 0.0
        
        # 如果是落笔动作，降低速度
        if pen_down:
            self.arm_group.set_max_velocity_scaling_factor(0.1)
        else:
            self.arm_group.set_max_velocity_scaling_factor(0.3)
            
        self.arm_group.set_pose_target(pose)
        success = self.arm_group.go(wait=True)
        self.arm_group.stop()
        self.arm_group.clear_pose_targets()
        return success
        
    def move_cartesian_path(self, waypoints):
        """使用笛卡尔路径规划（用于写字笔画）"""
        # 设置较低的速度用于写字
        self.arm_group.set_max_velocity_scaling_factor(0.1)
        
        # 计算笛卡尔路径
        (plan, fraction) = self.arm_group.compute_cartesian_path(
            waypoints,    # 路径点
            0.001,        # 步长(米)，设置得更小以获得更平滑的轨迹
            0.0          # 跳跃阈值
        )
        
        if fraction < 0.9:  # 如果规划的路径不完整
            self.get_logger().warn(f'笛卡尔路径规划不完整，仅完成 {fraction:.2%}')
            return False
            
        # 执行路径
        success = self.arm_group.execute(plan, wait=True)
        return success
        
    def write_stroke(self, points, char_x, char_y):
        """写一个笔画，结合使用MoveIt和笛卡尔路径规划"""
        z_up = self.writing_surface_height + 0.02  # 抬笔高度
        z_down = self.writing_surface_height  # 写字高度
        
        # 移动到笔画起点上方（使用MoveIt规划）
        start_x = char_x + points[0][0] * self.char_size
        start_y = char_y + points[0][1] * self.char_size
        self.move_to_point(start_x, start_y, z_up, False)
        
        # 落笔（使用MoveIt规划）
        self.move_to_point(start_x, start_y, z_down, True)
        
        # 准备笔画的路径点
        waypoints = []
        current_pose = self.arm_group.get_current_pose().pose
        
        # 添加所有笔画点到路径
        for point in points:
            pose = deepcopy(current_pose)
            pose.position.x = char_x + point[0] * self.char_size
            pose.position.y = char_y + point[1] * self.char_size
            pose.position.z = z_down
            waypoints.append(pose)
        
        # 使用笛卡尔路径执行笔画
        success = self.move_cartesian_path(waypoints)
        if not success:
            self.get_logger().warn('笔画执行失败')
            
        # 抬笔（使用MoveIt规划）
        self.move_to_point(waypoints[-1].position.x, 
                          waypoints[-1].position.y, 
                          z_up, False)
        
    def write_er(self, x, y):
        """写"二"字"""
        # 横
        self.write_stroke([(0.1, 0.8), (0.9, 0.8)], x, y)
        # 横
        self.write_stroke([(0.1, 0.2), (0.9, 0.2)], x, y)
        
    def write_si(self, x, y):
        """写"四"字"""
        # 撇
        self.write_stroke([(0.5, 0.9), (0.2, 0.5)], x, y)
        # 横
        self.write_stroke([(0.2, 0.7), (0.8, 0.7)], x, y)
        # 竖
        self.write_stroke([(0.5, 0.9), (0.5, 0.1)], x, y)
        # 横
        self.write_stroke([(0.2, 0.3), (0.8, 0.3)], x, y)
        
    def write_zai(self, x, y):
        """写"再"字"""
        # 横
        self.write_stroke([(0.2, 0.9), (0.8, 0.9)], x, y)
        # 竖
        self.write_stroke([(0.5, 0.8), (0.5, 0.6)], x, y)
        # 横
        self.write_stroke([(0.2, 0.5), (0.8, 0.5)], x, y)
        # 撇
        self.write_stroke([(0.4, 0.4), (0.2, 0.1)], x, y)
        # 捺
        self.write_stroke([(0.6, 0.4), (0.8, 0.1)], x, y)
        
    def write_jian(self, x, y):
        """写"见"字"""
        # 点
        self.write_stroke([(0.5, 0.9), (0.6, 0.8)], x, y)
        # 横折
        self.write_stroke([(0.2, 0.7), (0.8, 0.7), (0.8, 0.2)], x, y)
        # 横
        self.write_stroke([(0.2, 0.2), (0.7, 0.2)], x, y)
        
    def write_all(self):
        """写出"二四再见" """
        char_spacing = self.char_size * 1.5
        
        # 写"二"
        self.write_er(self.start_x, self.start_y)
        # 写"四"
        self.write_si(self.start_x + char_spacing, self.start_y)
        # 写"再"
        self.write_zai(self.start_x + char_spacing * 2, self.start_y)
        # 写"见"
        self.write_jian(self.start_x + char_spacing * 3, self.start_y)
        
def main(args=None):
    rclpy.init(args=args)
    writer = CharacterWriter()
    
    try:
        # 移动到初始位置
        writer.move_to_point(writer.start_x, writer.start_y, 
                           writer.writing_surface_height + 0.1, False)
        # 开始写字
        writer.write_all()
        
    except Exception as e:
        writer.get_logger().error(f'发生错误: {str(e)}')
        
    finally:
        # 结束后回到安全位置
        writer.move_to_point(0.2, 0.0, 0.3, False)
        writer.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
